const settings = {
  packname: '𝑨𝒏𝒅𝒓𝒐𝒎𝒆𝒅𝒂',
  author: '‎',
  botName: "𝑨𝒏𝒅𝒓𝒐𝒎𝒆𝒅𝒂",
  botOwner: 'zed', // Your name
  ownerNumber: '2348139617751','584263536392', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "This is a bot for managing group commands and automating tasks.",
  version: "1.0.0",
};

module.exports = settings;
